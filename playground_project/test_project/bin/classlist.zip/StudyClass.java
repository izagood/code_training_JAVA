package classlist;


public class StudyClass {
	
	private String className;
	private int classNum;
	
	public StudyClass(String className, int classNum) {
		this.className = className;
		this.classNum = classNum;
	}

	public String getClassName() {
		return className;
	}

	public int getClassNum() {
		return classNum;
	}
	
}
