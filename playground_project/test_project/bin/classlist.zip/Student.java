package classlist;

public class Student {
	
	private String stuname;
	private int stuNum;
	
	public Student(String stuname, int stuNum) {
		this.stuname = stuname;
		this.stuNum = stuNum;
	}

	public String getStuname() {
		return stuname;
	}

	public int getStuNum() {
		return stuNum;
	}
	
	
}
